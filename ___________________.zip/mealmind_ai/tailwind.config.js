module.exports = {
  content: ["./pages/*.{html,js}", "./index.html", "./js/*.js"],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: "#2D5A27", // Deep forest green for trust and nourishment
          50: "#F0F9F0",
          100: "#D4F1D4",
          200: "#A8E3A8",
          300: "#7DD57D",
          400: "#51C751",
          500: "#2D5A27",
          600: "#244821",
          700: "#1B361B",
          800: "#122414",
          900: "#09120E",
        },
        secondary: {
          DEFAULT: "#F4A261", // Warm amber for appetite and energy
          50: "#FEF7F0",
          100: "#FDEBD1",
          200: "#FBD7A3",
          300: "#F9C374",
          400: "#F7AF46",
          500: "#F4A261",
          600: "#E08B3A",
          700: "#B86F2E",
          800: "#8F5423",
          900: "#663817",
        },
        accent: {
          DEFAULT: "#E76F51", // Confident coral for primary actions
          50: "#FDF2F0",
          100: "#FADDD6",
          200: "#F5BBAD",
          300: "#F09984",
          400: "#EB775B",
          500: "#E76F51",
          600: "#D85A3F",
          700: "#B04832",
          800: "#883625",
          900: "#602418",
        },
        background: "#FEFEFE", // Clean canvas for food photography
        surface: "#F8F9FA", // Subtle card elevation and grouping
        text: {
          primary: "#1A1A1A", // Clear hierarchy for extended reading
          secondary: "#6B7280", // Supporting information without competition - gray-500
        },
        success: {
          DEFAULT: "#059669", // Natural growth and positive progress - emerald-600
          50: "#ECFDF5",
          100: "#D1FAE5",
          200: "#A7F3D0",
          300: "#6EE7B7",
          400: "#34D399",
          500: "#10B981",
          600: "#059669",
        },
        warning: {
          DEFAULT: "#D97706", // Gentle attention without alarm - amber-600
          50: "#FFFBEB",
          100: "#FEF3C7",
          200: "#FDE68A",
          300: "#FCD34D",
          400: "#FBBF24",
          500: "#F59E0B",
          600: "#D97706",
        },
        error: {
          DEFAULT: "#DC2626", // Clear concern with helpful intent - red-600
          50: "#FEF2F2",
          100: "#FEE2E2",
          200: "#FECACA",
          300: "#FCA5A5",
          400: "#F87171",
          500: "#EF4444",
          600: "#DC2626",
        },
        gray: {
          50: "#F9FAFB",
          100: "#F3F4F6",
          200: "#E5E7EB",
          300: "#D1D5DB",
          400: "#9CA3AF",
          500: "#6B7280",
          600: "#4B5563",
          700: "#374151",
          800: "#1F2937",
          900: "#111827",
        },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        inter: ['Inter', 'sans-serif'],
        accent: ['Playfair Display', 'serif'],
        playfair: ['Playfair Display', 'serif'],
      },
      fontWeight: {
        normal: '400',
        medium: '500',
        semibold: '600',
        bold: '700',
      },
      boxShadow: {
        'card': '0 1px 3px rgba(0, 0, 0, 0.1)',
        'modal': '0 4px 12px rgba(0, 0, 0, 0.15)',
      },
      transitionDuration: {
        'smooth': '300ms',
        'micro': '200ms',
      },
      transitionTimingFunction: {
        'smooth': 'ease-out',
      },
      animation: {
        'pulse-gentle': 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'scale-gentle': 'scale 200ms ease-out',
      },
      keyframes: {
        scale: {
          '0%': { transform: 'scale(1)' },
          '50%': { transform: 'scale(1.05)' },
          '100%': { transform: 'scale(1)' },
        },
      },
    },
  },
  plugins: [],
}